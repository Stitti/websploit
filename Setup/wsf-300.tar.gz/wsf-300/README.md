## [WebSploit Framework](https://github.com/The404Hacking/websploit)

![Screenshot](Screenshot.png?raw=ture "Screenshot")

Project in SourceForge : http://sourceforge.net/projects/websploit

Author : 0x0ptim0us (Fardin Allahverdinazhand)
Email & Report Bug : [0x0ptim0us@Gmail.Com](mailto:0x0ptim0us@Gmail.Com)
Blog : [http://0x0ptim0us.blogspot.com](http://0x0ptim0us.blogspot.com)

If your system doesn't have enough copies of the full text of the GNU
General Public License already, we have provided another one in the
"COPYING.GPL" file. 

# Supported Attack :
	[+]Autopwn - Used From Metasploit For Scan and Exploit Target Service
	[+]Browser AutoPWN - Exploit Victim Browser
	[+]wmap - Scan,Crawler Target Used From Metasploit wmap plugin
	[+]format infector - inject reverse & bind payload into file format
	[+]MLITM,XSS Phishing - Man Left In The Middle Attack
	[+]MITM - Man In The Middle Attack
	[+]USB Infection Attack - Create Executable Backdoor For Windows
	[+]MFOD Attack - Middle Finger Of Doom Attack
	[+]Java Applet Attack Vector 
	[+]ARP DOS - ARP Cache Denial Of Service Attack With Random MAC
	[+]Directory Scanner - Scan Target Directorys
	[+]Apache US - Scan Apache users
	[+]PHPMyAdmin - Scan PHPMyAdmin Login Page
	[+]Web Killer - Using From The TCPKill For Down Your WebSite On Network
	[+]Fake AP - Fake Access Point
	[+]FakeUpdate - Fake update attack 
  [+]Wifi Jammer - Wifi Jammer Attack
  [+]Wifi Dos - Wifi Dos RQ Attack
  [+]Wifi Mass De-authentication attack

## Download and Clone
> Download: [https://github.com/The404Hacking/websploit/archive/master.zip](https://github.com/The404Hacking/websploit/archive/master.zip)

> Clone: git clone [https://github.com/The404Hacking/websploit.git](https://github.com/The404Hacking/websploit.git)

## The404Hacking | Digital UnderGround Team
[The404Hacking](https://T.me/The404Hacking)

## Follow us !
[The404Hacking](https://T.me/The404Hacking) - [The404Cracking](https://T.me/The404Cracking)

[Instagram](https://instagram.com/The404Hacking) - [GitHub](https://github.com/The404Hacking)

[YouTube](http://yon.ir/youtube404) - [Aparat](http://www.aparat.com/The404Hacking)

## Email
[The404Hacking.Team@Gmail.Com](mailto:The404Hacking.Team@Gmail.Com)
